const mysql=require("mysql");
const path=require("path");
const con= mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "",
    database: "alumni"
});

con.connect(((err)=>{
    if(err){
        console.log(err);
    }
    else{
        console.log("Connection successfull");
    }
}))


module.exports.con = con;
