// const express =require("express");
// const app= express();
// const bodyparser=require("body-parser");
// app.use(bodyparser.json());
// app.use(bodyparser.urlencoded({extended:true}));
// const port =3000;

// // const mysql=require("./connection")

// app.get("/",(req,res)=>{
//     res.sendFile(__dirname+"/index.html");

// })


// app.post("/",(req,res)=>{
//     console.log(req.body);
// })
// app.listen(port);






const express = require("express");
const app = express();
const port = 3005
const mysql = require("./connection").con
// configuration
app.set("view engine", "hbs");
// app.set("views", "./view")
app.use(express.static('public'))


// app.use(express.static('public'))





app.get("/", (req, res) => {
    res.render("index")
});

app.get("/alumnicard", (req, res) => {
    res.render("alumnicard")
});



app.get("/addalumni", (req, res) => {
    // fetching data from form
    const { name, email,gender,company_placed,batch,salary,linkedin,descr } = req.query

    // Sanitization XSS...
    let qry = "select * from alumni_data where email=?";
    mysql.query(qry, [email], (err, d) => {
        if (err)
            throw err
        else {

            if (d.length > 0) {
                res.render("index", { msg1: true })
            } 
            else {

                // insert query
                let qry2 = "insert into alumni_data values(?,?,?,?,?,?,?,?)";
                mysql.query(qry2, [name, email,gender,company_placed,batch,salary,linkedin,descr], (err, results) => {
                    if(results==undefined){
                        // res.render("index",{msg3:true});
                        res.send("try again latter")
                    }
                    if (results.affectedRows > 0) {
console.log(results);
                        res.render("index", { msg2: true })
                    }
                })
            }
        }
    })
});



app.get("/view", (req, res) => {
    let qry = "select * from alumni_data";
    mysql.query(qry, (err, results) => {
        if (err) throw err
        else {
            res.render("alumnicard", { data: results });
            // console.log(data);
        }

    });

});



app.listen(port, (err) => {
    if (err)
        throw err
    else
        console.log("Server is running at port %d:", port);
});